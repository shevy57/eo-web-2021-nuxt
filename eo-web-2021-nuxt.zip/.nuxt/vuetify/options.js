export default {"theme":{"themes":{"light":{"primary":"#DBDBDB","secondary":"#b0bec5","anchor":"#8c9eff"}}}}
